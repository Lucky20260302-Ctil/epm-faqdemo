---
project: FE
issue_key: FE-939
issue_type: Bug QA
status: Closed
faq_score: 4.5
faq_category: 04_Data_Sync
faq_category_label: 資料與同步
tags: [faq, fe, data_sync, frontend]
jira_url: "https://ctil.atlassian.net/browse/FE-939"
created: 2021-03-26
resolved: 2022-08-18
resolution: Done
has_images: True
---

# FE-939: HKJC CR Patch

> **類型:** Bug QA | **狀態:** Closed
> **分類:** 資料與同步 | **FAQ 分數:** 4.5
> **解決日期:** 2022-08-18
> **負責人:** howard
> **組件:** Frontend

## 問題描述

1. copy and paste is disable under send e-receipt new UI, click paste will no action. 

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/d55881ba-d371-4455-8bca-2b5a96f59bec)（需 Jira 登入）
2. When select no send email, it still display notification job send to queue.

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/cf272681-14b8-4a82-9a18-d917d2c13d5f)（需 Jira 登入）

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/a8a22c89-cf66-4d2d-a2de-d6140bf0d717)（需 Jira 登入）


## 附件截圖

1. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/d55881ba-d371-4455-8bca-2b5a96f59bec)
2. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/cf272681-14b8-4a82-9a18-d917d2c13d5f)
3. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/a8a22c89-cf66-4d2d-a2de-d6140bf0d717)

## 相關資訊

- **Jira:** [FE-939](https://ctil.atlassian.net/browse/FE-939)
- **解決方式:** Done