---
project: BE
issue_key: BE-825
issue_type: Improvement
status: Closed
faq_score: 5.0
faq_category: 04_Data_Sync
faq_category_label: 資料與同步
tags: [faq, be, data_sync, backend-(web)]
jira_url: "https://ctil.atlassian.net/browse/BE-825"
created: 2023-10-26
resolved: 2023-11-13
resolution: Done
has_images: True
---

# BE-825: Display standard interface data import result

> **類型:** Improvement | **狀態:** Closed
> **分類:** 資料與同步 | **FAQ 分數:** 5.0
> **解決日期:** 2023-11-13
> **負責人:** Sherman tse
> **組件:** Backend (Web)

## 問題描述

AS2000 and SE8008 are not able to display the standard interface data import result after
the recent LANDS new data import update.

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/f6657b7c-e89d-4ec6-ab13-b91bd360ff3f)（需 Jira 登入）
 

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/f793a068-5fe8-4f98-9dda-50e49b1cdd82)（需 Jira 登入）
 

@@Jerry Wong
Please add the old description into the filename

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/e294592f-58c6-4415-9f11-b9eb9683ffce)（需 Jira 登入）
 

> 📎 **image** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/2efc6cfb-1cdf-47d2-b415-2814240c926c)（需 Jira 登入）
 



## 附件截圖

1. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/f6657b7c-e89d-4ec6-ab13-b91bd360ff3f)
2. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/f793a068-5fe8-4f98-9dda-50e49b1cdd82)
3. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/e294592f-58c6-4415-9f11-b9eb9683ffce)
4. 📎 **image** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/2efc6cfb-1cdf-47d2-b415-2814240c926c)

## 相關資訊

- **Jira:** [BE-825](https://ctil.atlassian.net/browse/BE-825)
- **解決方式:** Done