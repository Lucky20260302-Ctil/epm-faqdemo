---
project: MP
issue_key: MP-432
issue_type: Task
status: Closed
faq_score: 6.0
faq_category: 04_Data_Sync
faq_category_label: 資料與同步
tags: [faq, mp, data_sync, mpos-api]
jira_url: "https://ctil.atlassian.net/browse/MP-432"
created: 2021-05-17
resolved: 2021-07-20
resolution: Done
has_images: False
---

# MP-432: MPOS update to FE core V72.02R09

> **類型:** Task | **狀態:** Closed
> **分類:** 資料與同步 | **FAQ 分數:** 6.0
> **解決日期:** 2021-07-20
> **負責人:** kingsley_ng
> **組件:** MPOS API

## 問題描述

1. DotNet PCD Write Sales Item VAT Rate if tblconfig.USE_ITEMLEVEL_VAT='I',Sales Memo Updated (KTS 210422 v720.02R06E, v750.01R01A) - MPOS

2. DotNet Write PCD - RV '23' Move to after write Payment PCD '09' - Sales (KTS 210422 v720.02R6E, v720.02R07F, v750.01R01)   - MPOS




## Jira Comments

> **kingsley_ng** (2021-05-21):
> Coach Request don't upgrade Core 7.2.02R08  in 3.9.5 

## 相關資訊

- **Jira:** [MP-432](https://ctil.atlassian.net/browse/MP-432)
- **解決方式:** Done