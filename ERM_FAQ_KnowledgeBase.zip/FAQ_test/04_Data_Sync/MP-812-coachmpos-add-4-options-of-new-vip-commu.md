---
project: MP
issue_key: MP-812
issue_type: Improvement
status: Closed
faq_score: 5.0
faq_category: 04_Data_Sync
faq_category_label: 資料與同步
tags: [faq, mp, data_sync, mpos]
jira_url: "https://ctil.atlassian.net/browse/MP-812"
created: 2026-02-23
resolved: 2026-05-05
resolution: Done
has_images: True
---

# MP-812: [Coach][MPOS] Add 4 options of New VIP Communication Channel in New member section 

> **類型:** Improvement | **狀態:** Closed
> **分類:** 資料與同步 | **FAQ 分數:** 5.0
> **解決日期:** 2026-05-05
> **負責人:** Sherman tse
> **組件:** MPOS

## 問題描述

[Coach][MPOS] Add 4 options of New VIP Communication Channel in New member section

No EDM, No DM, No Phone, No SMS

Related Configs:

NVIPINPUTCOMMOPT= Y/N   Y- support above 4 Option

NVIPINPUTCOMMOPT_DEFAULTNO= Y/N   Y - Set New VIP Comm Channel default Value to No

*Each Option is clickable

> 📎 **image-20260223-093538.png** — [查看附件](https://ctil.atlassian.net/rest/api/3/attachment/content/9e607196-657a-4aba-aee1-4dedcf98e954)（需 Jira 登入）


## 附件截圖

1. 📎 **image-20260223-093538.png** — [在 Jira 查看](https://ctil.atlassian.net/rest/api/3/attachment/content/9e607196-657a-4aba-aee1-4dedcf98e954)


## Jira Comments

> **Daniel Leung** (2026-02-26):
> mpos: 3.31.0-20260225.1 mpos api : \\ds411\share\POS_MPOS_Release\3.31.X\3.31.0-20260226.1b1  

> **Andrew_Au** (2026-05-05):
>  Please update the ticket status

> **Sherman tse** (2026-05-05):
> verified on QA

> **Automation for Jira** (2026-05-05):
> Issue has been created since Days since: 70 Week since : 10 Issue due date difference Days since :  Weeks since: 

## 相關資訊

- **Jira:** [MP-812](https://ctil.atlassian.net/browse/MP-812)
- **解決方式:** Done